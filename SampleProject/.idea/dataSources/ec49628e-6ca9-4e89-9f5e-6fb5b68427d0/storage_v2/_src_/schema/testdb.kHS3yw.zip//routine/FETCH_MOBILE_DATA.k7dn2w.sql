create
    definer = root@localhost procedure FETCH_MOBILE_DATA(IN MOBILE_ID_MOW bigint)
BEGIN
    SELECT A.ACTUAL_MOBILE_NAME AS MOBILE_NAME,
           A.RAM                AS RAM,
           A.ID                 AS ID,
           A.COLOR              AS COLOR,
           B.MOBILE_LINK        AS LINK,
           B.PRICE              AS PRICE,
           C.SELLER_NAME        AS SELLER_NAME,
           A.IMAGE_URL          AS IMAGE_URL
    FROM MOBILE_DETAILS A
             JOIN MOBILE_SELLER_DETAILS B ON A.ID = B.MOBILE_ID AND A.ID = MOBILE_ID_MOW
             JOIN SELLER_DETAILS C ON C.ID = B.SELLER_ID;
END;

